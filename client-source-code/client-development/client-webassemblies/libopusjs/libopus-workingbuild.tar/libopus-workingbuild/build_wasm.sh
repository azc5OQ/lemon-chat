#!/bin/bash
#
# Builds src/wasm/libopus.wasm from opus-1.5.2/ + speexdsp/ (WSL Ubuntu + emsdk).
# This REPLACED the old Makefile flow (opus/ submodule @ v1.1.2, custom 9-arg
# opus_decode_float) on 2026-07-07. The wasm is now STOCK opus - 6-arg decode -
# and packet loss concealment lives in JS (audio-opus-glue.js conceal_lost_frame).
# opus/ + Makefile are kept only as history; dist/ holds the shipped build and
# dist/test_plc.js is a node smoke test (encode -> decode -> 2x PLC -> decode).
#
# One-time setup inside WSL:
#   git clone https://github.com/emscripten-core/emsdk.git ~/emsdk
#   ~/emsdk/emsdk install 3.1.32 && ~/emsdk/emsdk activate 3.1.32
#
# emsdk MUST stay on 3.1.32 (pre-3.1.33): the hand-maintained glue
# src/scripts/vendor/libopus.emscripten.js supplies emscripten_memcpy_big,
# which newer emscriptens renamed. NEVER regenerate that glue from a build -
# it carries the base64 @@WASM@@ loader, the worker cloning and the wasi stubs.
# Only the .wasm is swapped.
#
# After a successful build:
#   cp dist/libopus.wasm ../../../src/wasm/libopus.wasm
#   cd ../../.. && python3 build.py
#
set -e
source ~/emsdk/emsdk_env.sh

HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$HOME/opusbuild-workdir"
mkdir -p "$WORK" "$HERE/dist"

# building on /mnt/c is slow and cmake sometimes trips on 9p; build in the WSL fs
rsync -a --exclude=build "$HERE/opus-1.5.2/" "$WORK/opus/"

# 1. opus 1.5.2 static lib.
#    - intrinsics OFF: cmake sees "x86" and enables SSE/AVX2 files emcc cannot compile
#    - stack protector / fortify OFF: __stack_chk_fail is unresolved at wasm link
emcmake cmake -S "$WORK/opus" -B "$WORK/opus/build" -DCMAKE_BUILD_TYPE=Release \
    -DOPUS_BUILD_SHARED_LIBRARY=OFF -DOPUS_BUILD_TESTING=OFF -DOPUS_BUILD_PROGRAMS=OFF \
    -DOPUS_DISABLE_INTRINSICS=ON -DOPUS_STACK_PROTECTOR=OFF -DOPUS_FORTIFY_SOURCE=OFF
cmake --build "$WORK/opus/build" -j"$(nproc)"

# 2. speex resampler, compiled standalone from the vendored speexdsp tree
#    (no autotools/libtool needed; OUTSIDE_SPEEX + RANDOM_PREFIX give the plain
#    speex_resampler_* symbol names the JS expects)
emcc -O2 -c "$HERE/speexdsp/libspeexdsp/resample.c" -o "$WORK/resample.o" \
    -DOUTSIDE_SPEEX -DFLOATING_POINT -DEXPORT= -DRANDOM_PREFIX=speex \
    -I"$HERE/speexdsp/include/speex" -I"$HERE/speexdsp/libspeexdsp"

# 3. link. same flags/export list as the old Makefile. the emitted dist/libopus.js
#    glue is NOT shipped (see header) - only dist/libopus.wasm is
emcc -o "$HERE/dist/libopus.js" -Wno-expansion-to-defined -s WASM=1 -s ALLOW_MEMORY_GROWTH=1 \
    -s EXPORTED_FUNCTIONS="[_opus_encoder_create,_opus_encode_float,_opus_encoder_ctl,_opus_encoder_destroy,_malloc,_free,_opus_decoder_create,_opus_decode_float,_opus_decoder_ctl,_opus_decoder_destroy,_speex_resampler_init,_speex_resampler_destroy,_speex_resampler_process_interleaved_float]" \
    -s EXPORTED_RUNTIME_METHODS="[setValue,getValue,allocate]" \
    "$WORK/opus/build/libopus.a" "$WORK/resample.o"

echo
echo "built: $HERE/dist/libopus.wasm"
echo "imports must be exactly: env.emscripten_memcpy_big, env.emscripten_resize_heap,"
echo "  wasi fd_close/fd_write/fd_seek, env.abort (all provided by the hand-edited glue)"
echo "smoke test: node dist/test_plc.js   (edit its require path to this dist/ first)"
