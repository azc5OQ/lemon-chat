# stunnel known bugs


* The shared library for transparent proxy does not support IPv6.
